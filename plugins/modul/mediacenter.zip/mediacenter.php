<?php
// Paths
$moviesFolder = ROOT_DIR . 'media/Movies';
$seriesFolder = ROOT_DIR . 'media/Series';

// List videos by extension
// Klasörleri oluştur ve oluşturulamazsa hata vermemesi için @ kullan veya hata kontrolü yap
if (!is_dir($moviesFolder)) {
    if (!mkdir($moviesFolder, 0755, true)) {
        die("Hata: 'Movies' klasörü oluşturulamadı. İzinleri kontrol edin.");
    }
}

if (!is_dir($seriesFolder)) {
    if (!mkdir($seriesFolder, 0755, true)) {
        die("Hata: 'Series' klasörü oluşturulamadı. İzinleri kontrol edin.");
    }
}
function listVideos($folder)
{
    $files = glob($folder . '/*.{mp4,mkv,webm}', GLOB_BRACE);
    natsort($files);
    return $files;
}

function coverPath($video)
{
    $dir = dirname($video);
    $base = pathinfo($video, PATHINFO_FILENAME);

    foreach (['jpg', 'png', 'webp'] as $ext) {
        $cover = "$dir/$base.$ext";
        if (file_exists($cover)) {
            return str_replace(ROOT_DIR, '', $cover);
        }
    }
    return "cdn/images/mediacenter/default-cover.png"; // fallback image
}

// Find sidecar subtitles (.vtt) near video file
function findSubtitles($videoPath)
{
    $dir = dirname($videoPath);
    $base = pathinfo($videoPath, PATHINFO_FILENAME);
    // Candidates: same basename, any lang suffix
    $subs = glob($dir . "/{$base}*.vtt");
    $out = [];
    foreach ($subs as $s) {
        $label = basename($s);
        // try extract language from filename suffix (e.g., movie.en.vtt)
        $lang = 'en';
        if (preg_match('/\.(\w{2,3})\.vtt$/i', $s, $m)) {
            $lang = strtolower($m[1]);
        }
        $out[] = ['src' => webPath($s), 'label' => $label, 'lang' => $lang];
    }
    return $out;
}

// Helpers
function webPath($file)
{
    return str_replace(ROOT_DIR, '', $file);
}

$movies = listVideos($moviesFolder);
$series = listVideos($seriesFolder);
?>


<main class="page">

    <!-- PLAYER AREA -->
    <div id="playerWrapper">
        <video id="player" crossorigin="anonymous" playsinline></video>

        <!-- MODERN CONTROL BAR -->
        <div class="controls-bg">
            <div class="controls">
                <button id="rew" class="btn btn-light"> <i class="fa fa-backward"></i> </button>
                <button id="ff" class="btn btn-light"> <i class="fa fa-forward"></i> </button>
                <button id="playPause" class="btn btn-light"> <i class="fa fa-play"></i> </button>

                <input id="seekBar" type="range" value="0" min="0" max="100" step="0.1">
                <span id="timeText">00:00 / 00:00</span>

                <select id="speedSelect" title="Speed">
                    <option value="0.75">0.75x</option>
                    <option value="1" selected>1x</option>
                    <option value="1.25">1.25x</option>
                    <option value="1.5">1.5x</option>
                    <option value="2">2x</option>
                </select>

                <select id="subtitleSelect" title="Subtitles">
                    <option value="">No Subtitles</option>
                </select>

                <select id="audioSelect" title="Audio">
                    <option value="">Default Audio</option>
                </select>

                <button id="fsBtn">⛶ Fullscreen</button>
            </div>
        </div>

        <!-- INFO BADGES -->
        <div class="video-badges">
            <span id="hdrBadge"></span>
            <span id="codecBadge"></span>
            <span id="resBadge"></span>
            <span id="bitBadge"></span>
        </div>

        <div id="nextEpBox" class="next-ep">Next episode starts in 5 seconds…</div>
    </div>

    <h2><i class="fa fa-film me-2"></i> Movies</h2>
    <div class="grid">
        <?php foreach ($movies as $m): ?>
            <?php $subs = findSubtitles($m); ?>
            <div class="item" data-src="<?= htmlspecialchars(webPath($m)) ?>"
                data-subs='<?= json_encode($subs, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>'>
                <div class="thumb" style="background-image:url('<?= coverPath($m) ?>')"></div>
                <div class="name"><?= basename($m) ?></div>
            </div>
        <?php endforeach; ?>
    </div>

    <h2><i class="fa fa-tv me-2"></i> Series</h2>
    <div class="grid">
        <?php foreach ($series as $s): ?>
            <?php $subs = findSubtitles($s); ?>
            <div class="item episode" data-src="<?= htmlspecialchars(webPath($s)) ?>"
                data-subs='<?= json_encode($subs, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>'>
                <div class="thumb" style="background-image:url('<?= coverPath($s) ?>')"></div>
                <div class="name"><?= basename($s) ?></div>
            </div>
        <?php endforeach; ?>
    </div>

    <div id="stats" class="mt-3"> <i class="fa fa-chart-bar me-2"></i> Total watch time: <span
            id="totalMinutes">0</span> minutes </div>

</main>